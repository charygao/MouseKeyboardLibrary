﻿using System;

namespace CharyMacroRecorder
{
    [Serializable]
    public class MacroEvent
    {
        public System.EventArgs EventArgs;
        public global::CharyMacroRecorder.MacroEventType MacroEventType;
        public int TimeSinceLastEvent;

        public MacroEvent(global::CharyMacroRecorder.MacroEventType macroEventType, System.EventArgs eventArgs, int timeSinceLastEvent)
        {
            this.MacroEventType = macroEventType;
            this.EventArgs = eventArgs;
            this.TimeSinceLastEvent = timeSinceLastEvent;
        }
    }

    [Serializable]
    public enum MacroEventType    {
        MouseMove,
        MouseDown,
        MouseUp,
        MouseWheel,
        KeyDown,
        KeyUp
    }
}