﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Windows.Forms;
using System.Xml;
using Microsoft.Win32;
using MouseKeyboardLibrary;

namespace CharyMacroRecorder
{
    public class MacroForm : Form
    {
        private bool _isPlayingScript;
        private Button _buttonSetShotcut;
        private ContextMenuStrip _contextMenuStrip1;
        private IContainer icontainer_0;
        private int _int0;
        private int _int1;
        private KeyboardHook _keyboardHook0;
        private KeyboardHook _keyboardHook1;
        private Keys keys_Start;
        private Keys keys_StopRecord;
        private Keys keys_2;
        private Keys keys_3;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private List<MacroEvent> _list0;
        private NumericUpDown loopnumericUpDown;
        private MouseHook mouseHook_0;
        private NotifyIcon notifyIcon_0;
        private Button openbutton;
        private Button _playBackMacroButton;
        private Button recordStartButton;
        private Button recordStopButton;
        private Button savebutton;
        private NumericUpDown spannumericUpDown;
        private Button StopBackMacroButton;
        private TextBox textBoxPlay;
        private TextBox textBoxStart;
        private TextBox textBoxStop;
        private TextBox textBoxStopPlay;
        public static BackgroundWorker workerCmd;
        private ToolStripMenuItem 打开主窗体ToolStripMenuItem;
        private ToolStripMenuItem 访问官网ToolStripMenuItem;
        private IContainer components;
        private StatusStrip statusStrip1;
        private ToolStripStatusLabel toolStripStatusLabelCurrentState;
        private ToolStripStatusLabel tsslCurrentState;
        private ToolStripStatusLabel toolStripStatusLabel1;
        private Label label7;
        private ToolStripStatusLabel toolStripStatusLabel2;
        private ToolStripMenuItem 退出ToolStripMenuItem;

        static MacroForm()
        {
            workerCmd = new BackgroundWorker();
        }

        public MacroForm()
        {
            this._list0 = new List<MacroEvent>();
            this._int0 = 0;
            this._isPlayingScript = false;
            this.mouseHook_0 = new MouseHook();
            this._keyboardHook0 = new KeyboardHook();
            this._keyboardHook1 = new KeyboardHook();
            this._int1 = 0;
            this.icontainer_0 = null;
            this.InitializeComponent();
            this.mouseHook_0.MouseMove += new MouseEventHandler(this.mouseHook_0_MouseMove);
            this.mouseHook_0.MouseWheel += new MouseEventHandler(this.mouseHook_0_MouseWheel);
            this.mouseHook_0.MouseDown += new MouseEventHandler(this.mouseHook_0_MouseDown);
            this.mouseHook_0.MouseUp += new MouseEventHandler(this.mouseHook_0_MouseUp);
            this._keyboardHook0.KeyDown += new KeyEventHandler(this.keyboardHook_0_KeyDown);
            this._keyboardHook0.KeyUp += new KeyEventHandler(this.keyboardHook_0_KeyUp);
            this._keyboardHook1.KeyDown += new KeyEventHandler(this.keyboardHook_1_KeyDown);
            this._keyboardHook1.KeyUp += new KeyEventHandler(this.keyboardHook_1_KeyUp);
            workerCmd.DoWork += new DoWorkEventHandler(this.method_0);
            workerCmd.WorkerSupportsCancellation = true;
            this.keys_Start = Keys.F5;
            this.keys_StopRecord = Keys.F6;
            this.keys_2 = Keys.F7;
            this.keys_3 = Keys.F8;
            this._keyboardHook1.Start();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.icontainer_0 != null))
            {
                this.icontainer_0.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MacroForm));
            this.recordStartButton = new System.Windows.Forms.Button();
            this.recordStopButton = new System.Windows.Forms.Button();
            this._playBackMacroButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.loopnumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.spannumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.StopBackMacroButton = new System.Windows.Forms.Button();
            this.savebutton = new System.Windows.Forms.Button();
            this.openbutton = new System.Windows.Forms.Button();
            this.textBoxStart = new System.Windows.Forms.TextBox();
            this.textBoxStop = new System.Windows.Forms.TextBox();
            this.textBoxPlay = new System.Windows.Forms.TextBox();
            this.textBoxStopPlay = new System.Windows.Forms.TextBox();
            this.notifyIcon_0 = new System.Windows.Forms.NotifyIcon(this.components);
            this._contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.打开主窗体ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.访问官网ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._buttonSetShotcut = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabelCurrentState = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsslCurrentState = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.label7 = new System.Windows.Forms.Label();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            ((System.ComponentModel.ISupportInitialize)(this.loopnumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spannumericUpDown)).BeginInit();
            this._contextMenuStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // recordStartButton
            // 
            resources.ApplyResources(this.recordStartButton, "recordStartButton");
            this.recordStartButton.Name = "recordStartButton";
            this.recordStartButton.UseVisualStyleBackColor = true;
            this.recordStartButton.Click += new System.EventHandler(this.recordStartButton_Click);
            // 
            // recordStopButton
            // 
            resources.ApplyResources(this.recordStopButton, "recordStopButton");
            this.recordStopButton.Name = "recordStopButton";
            this.recordStopButton.UseVisualStyleBackColor = true;
            this.recordStopButton.Click += new System.EventHandler(this.recordStopButton_Click);
            // 
            // playBackMacroButton
            // 
            resources.ApplyResources(this._playBackMacroButton, "_playBackMacroButton");
            this._playBackMacroButton.Name = "_playBackMacroButton";
            this._playBackMacroButton.UseVisualStyleBackColor = true;
            this._playBackMacroButton.Click += new System.EventHandler(this.playBackMacroButton_Click);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // loopnumericUpDown
            // 
            resources.ApplyResources(this.loopnumericUpDown, "loopnumericUpDown");
            this.loopnumericUpDown.Maximum = new decimal(new int[] {
            999999999,
            0,
            0,
            0});
            this.loopnumericUpDown.Name = "loopnumericUpDown";
            this.loopnumericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            // 
            // spannumericUpDown
            // 
            resources.ApplyResources(this.spannumericUpDown, "spannumericUpDown");
            this.spannumericUpDown.Maximum = new decimal(new int[] {
            999999999,
            0,
            0,
            0});
            this.spannumericUpDown.Name = "spannumericUpDown";
            this.spannumericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // StopBackMacroButton
            // 
            resources.ApplyResources(this.StopBackMacroButton, "StopBackMacroButton");
            this.StopBackMacroButton.Name = "StopBackMacroButton";
            this.StopBackMacroButton.UseVisualStyleBackColor = true;
            this.StopBackMacroButton.Click += new System.EventHandler(this.StopBackMacroButton_Click);
            // 
            // savebutton
            // 
            resources.ApplyResources(this.savebutton, "savebutton");
            this.savebutton.Name = "savebutton";
            this.savebutton.UseVisualStyleBackColor = true;
            this.savebutton.Click += new System.EventHandler(this.savebutton_Click);
            // 
            // openbutton
            // 
            resources.ApplyResources(this.openbutton, "openbutton");
            this.openbutton.Name = "openbutton";
            this.openbutton.UseVisualStyleBackColor = true;
            this.openbutton.Click += new System.EventHandler(this.openbutton_Click);
            // 
            // textBoxStart
            // 
            resources.ApplyResources(this.textBoxStart, "textBoxStart");
            this.textBoxStart.Name = "textBoxStart";
            this.textBoxStart.MouseLeave += new System.EventHandler(this.textBoxStart_MouseLeave);
            this.textBoxStart.MouseHover += new System.EventHandler(this.textBoxStart_MouseHover);
            // 
            // textBoxStop
            // 
            resources.ApplyResources(this.textBoxStop, "textBoxStop");
            this.textBoxStop.Name = "textBoxStop";
            this.textBoxStop.MouseLeave += new System.EventHandler(this.textBoxStop_MouseLeave);
            this.textBoxStop.MouseHover += new System.EventHandler(this.textBoxStop_MouseHover);
            // 
            // textBoxPlay
            // 
            resources.ApplyResources(this.textBoxPlay, "textBoxPlay");
            this.textBoxPlay.Name = "textBoxPlay";
            this.textBoxPlay.MouseLeave += new System.EventHandler(this.textBoxPlay_MouseLeave);
            this.textBoxPlay.MouseHover += new System.EventHandler(this.textBoxPlay_MouseHover);
            // 
            // textBoxStopPlay
            // 
            resources.ApplyResources(this.textBoxStopPlay, "textBoxStopPlay");
            this.textBoxStopPlay.Name = "textBoxStopPlay";
            this.textBoxStopPlay.MouseLeave += new System.EventHandler(this.textBoxStopPlay_MouseLeave);
            this.textBoxStopPlay.MouseHover += new System.EventHandler(this.textBoxStopPlay_MouseHover);
            // 
            // notifyIcon_0
            // 
            this.notifyIcon_0.ContextMenuStrip = this._contextMenuStrip1;
            resources.ApplyResources(this.notifyIcon_0, "notifyIcon_0");
            this.notifyIcon_0.MouseClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon_0_MouseClick);
            // 
            // _contextMenuStrip1
            // 
            this._contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.打开主窗体ToolStripMenuItem,
            this.访问官网ToolStripMenuItem,
            this.退出ToolStripMenuItem});
            this._contextMenuStrip1.Name = "_contextMenuStrip1";
            resources.ApplyResources(this._contextMenuStrip1, "_contextMenuStrip1");
            // 
            // 打开主窗体ToolStripMenuItem
            // 
            this.打开主窗体ToolStripMenuItem.Name = "打开主窗体ToolStripMenuItem";
            resources.ApplyResources(this.打开主窗体ToolStripMenuItem, "打开主窗体ToolStripMenuItem");
            this.打开主窗体ToolStripMenuItem.Click += new System.EventHandler(this.打开主窗体ToolStripMenuItem_Click);
            // 
            // 访问官网ToolStripMenuItem
            // 
            this.访问官网ToolStripMenuItem.Name = "访问官网ToolStripMenuItem";
            resources.ApplyResources(this.访问官网ToolStripMenuItem, "访问官网ToolStripMenuItem");
            this.访问官网ToolStripMenuItem.Click += new System.EventHandler(this.访问官网ToolStripMenuItem_Click);
            // 
            // 退出ToolStripMenuItem
            // 
            this.退出ToolStripMenuItem.Name = "退出ToolStripMenuItem";
            resources.ApplyResources(this.退出ToolStripMenuItem, "退出ToolStripMenuItem");
            this.退出ToolStripMenuItem.Click += new System.EventHandler(this.退出ToolStripMenuItem_Click);
            // 
            // _buttonSetShotcut
            // 
            resources.ApplyResources(this._buttonSetShotcut, "_buttonSetShotcut");
            this._buttonSetShotcut.Name = "_buttonSetShotcut";
            this._buttonSetShotcut.UseVisualStyleBackColor = true;
            this._buttonSetShotcut.Click += new System.EventHandler(this.xyLyvkmwZ);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabelCurrentState,
            this.tsslCurrentState,
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2});
            resources.ApplyResources(this.statusStrip1, "statusStrip1");
            this.statusStrip1.Name = "statusStrip1";
            // 
            // toolStripStatusLabelCurrentState
            // 
            this.toolStripStatusLabelCurrentState.Name = "toolStripStatusLabelCurrentState";
            resources.ApplyResources(this.toolStripStatusLabelCurrentState, "toolStripStatusLabelCurrentState");
            // 
            // tsslCurrentState
            // 
            this.tsslCurrentState.Name = "tsslCurrentState";
            resources.ApplyResources(this.tsslCurrentState, "tsslCurrentState");
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            resources.ApplyResources(this.toolStripStatusLabel1, "toolStripStatusLabel1");
            this.toolStripStatusLabel1.Spring = true;
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            resources.ApplyResources(this.toolStripStatusLabel2, "toolStripStatusLabel2");
            // 
            // MacroForm
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.textBoxStopPlay);
            this.Controls.Add(this._buttonSetShotcut);
            this.Controls.Add(this.textBoxPlay);
            this.Controls.Add(this.textBoxStop);
            this.Controls.Add(this.textBoxStart);
            this.Controls.Add(this.openbutton);
            this.Controls.Add(this.savebutton);
            this.Controls.Add(this.StopBackMacroButton);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.spannumericUpDown);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.loopnumericUpDown);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label1);
            this.Controls.Add(this._playBackMacroButton);
            this.Controls.Add(this.recordStopButton);
            this.Controls.Add(this.recordStartButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "MacroForm";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MacroForm_FormClosing);
            this.Load += new System.EventHandler(this.MacroForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.loopnumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spannumericUpDown)).EndInit();
            this._contextMenuStrip1.ResumeLayout(false);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void keyboardHook_0_KeyDown(object sender, KeyEventArgs e)
        {
            this._list0.Add(new MacroEvent(MacroEventType.KeyDown, e, Environment.TickCount - this._int0));
            this._int0 = Environment.TickCount;
        }

        private void keyboardHook_0_KeyUp(object sender, KeyEventArgs e)
        {
            this._list0.Add(new MacroEvent(MacroEventType.KeyUp, e, Environment.TickCount - this._int0));
            this._int0 = Environment.TickCount;
        }

        private void keyboardHook_1_KeyDown(object sender, KeyEventArgs e)
        {
            if (this._int1 != 0)
            {
                switch (this._int1)
                {
                    case 1:
                        this.textBoxStart.Text = e.KeyData.ToString();
                        this.keys_Start = (Keys) Enum.Parse(typeof(Keys), this.textBoxStart.Text, true);
                        break;

                    case 2:
                        this.textBoxStop.Text = e.KeyData.ToString();
                        this.keys_StopRecord = (Keys) Enum.Parse(typeof(Keys), this.textBoxStop.Text, true);
                        break;

                    case 3:
                        this.textBoxPlay.Text = e.KeyData.ToString();
                        this.keys_2 = (Keys) Enum.Parse(typeof(Keys), this.textBoxPlay.Text, true);
                        break;

                    case 4:
                        this.textBoxStopPlay.Text = e.KeyData.ToString();
                        this.keys_3 = (Keys) Enum.Parse(typeof(Keys), this.textBoxStopPlay.Text, true);
                        break;
                }
            }
            else if (e.KeyData == this.keys_Start)
            {
                this._list0.Clear();
                this._int0 = Environment.TickCount;
                this._isPlayingScript = false;
                this._keyboardHook0.Start();
                this.mouseHook_0.Start();
            }
            else if (e.KeyData == this.keys_StopRecord)
            {
                this._isPlayingScript = false;
                this._keyboardHook0.Stop();
                this.mouseHook_0.Stop();
            }
            else if (e.KeyData == this.keys_2)
            {
                this._isPlayingScript = true;
                if (!workerCmd.IsBusy)
                {
                    workerCmd.RunWorkerAsync();
                }
            }
            else if (e.KeyData == this.keys_3)
            {
                this._isPlayingScript = false;
                if (workerCmd.IsBusy)
                {
                    workerCmd.CancelAsync();
                }
            }
        }

        private void keyboardHook_1_KeyUp(object sender, KeyEventArgs e)
        {
            if (this._int1 == 0)
            {
                if (e.KeyData == this.keys_Start)
                {
                    this._list0.Clear();
                    this._int0 = Environment.TickCount;
                    this._isPlayingScript = false;
                    this._keyboardHook0.Start();
                    this.mouseHook_0.Start();
                }
                else if (e.KeyData == this.keys_StopRecord)
                {
                    this._isPlayingScript = false;
                    this._keyboardHook0.Stop();
                    this.mouseHook_0.Stop();
                }
                else if (e.KeyData == this.keys_2)
                {
                    this._isPlayingScript = true;
                    if (!workerCmd.IsBusy)
                    {
                        workerCmd.RunWorkerAsync();
                    }
                }
                else if (e.KeyData == this.keys_Start)
                {
                    this._isPlayingScript = false;
                    if (workerCmd.IsBusy)
                    {
                        workerCmd.CancelAsync();
                    }
                }
            }
        }

        private void MacroForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            base.Hide();
            base.ShowInTaskbar = false;
            this.notifyIcon_0.Visible = false;
            this.notifyIcon_0.Dispose();
        }

        private void MacroForm_Load(object sender, EventArgs e)
        {
        }

        private void method_0(object sender, DoWorkEventArgs e)
        {
            for (int i = 0; i < Convert.ToDecimal(this.loopnumericUpDown.Value)+1; i++)
            {
                TimeSpan span;
                using (List<MacroEvent>.Enumerator enumerator = this._list0.GetEnumerator())
                {
                    while (enumerator.MoveNext())
                    {
                        MouseEventArgs eventArgs;
                        KeyEventArgs args2;
                        MacroEvent current = enumerator.Current;
                        Thread.Sleep(current.TimeSinceLastEvent);
                        if (((BackgroundWorker) sender).CancellationPending)
                        {
                            goto Label_011C;
                        }
                        switch (current.MacroEventType)
                        {
                            case MacroEventType.MouseMove:
                                eventArgs = (MouseEventArgs) current.EventArgs;
                                MouseSimulator.X = eventArgs.X;
                                MouseSimulator.Y = eventArgs.Y;
                                break;

                            case MacroEventType.MouseDown:
                                eventArgs = (MouseEventArgs) current.EventArgs;
                                MouseSimulator.MouseDown(eventArgs.Button);
                                break;

                            case MacroEventType.MouseUp:
                                eventArgs = (MouseEventArgs) current.EventArgs;
                                MouseSimulator.MouseUp(eventArgs.Button);
                                break;

                            case MacroEventType.MouseWheel:
                                eventArgs = (MouseEventArgs) current.EventArgs;
                                MouseSimulator.MouseWheel(eventArgs.Delta);
                                break;

                            case MacroEventType.KeyDown:
                                args2 = (KeyEventArgs) current.EventArgs;
                                KeyboardSimulator.KeyDown(args2.KeyData);
                                break;

                            case MacroEventType.KeyUp:
                                args2 = (KeyEventArgs) current.EventArgs;
                                KeyboardSimulator.KeyUp(args2.KeyData);
                                break;
                        }
                    }
                    goto Label_0133;
                Label_011C:
                    e.Cancel = true;
                }
            Label_0133:
                span = new TimeSpan(0, 0, (int) this.spannumericUpDown.Value);
                Thread.Sleep(span);
            }
        }

        private void mouseHook_0_MouseDown(object sender, MouseEventArgs e)
        {
            this._list0.Add(new MacroEvent(MacroEventType.MouseDown, e, Environment.TickCount - this._int0));
            this._int0 = Environment.TickCount;
        }

        private void mouseHook_0_MouseMove(object sender, MouseEventArgs e)
        {
            this._list0.Add(new MacroEvent(MacroEventType.MouseMove, e, Environment.TickCount - this._int0));
            this._int0 = Environment.TickCount;
        }

        private void mouseHook_0_MouseUp(object sender, MouseEventArgs e)
        {
            this._list0.Add(new MacroEvent(MacroEventType.MouseUp, e, Environment.TickCount - this._int0));
            this._int0 = Environment.TickCount;
        }

        private void mouseHook_0_MouseWheel(object sender, MouseEventArgs e)
        {
            this._list0.Add(new MacroEvent(MacroEventType.MouseWheel, e, Environment.TickCount - this._int0));
            this._int0 = Environment.TickCount;
        }

        private void notifyIcon_0_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                base.Show();
                base.ShowInTaskbar = true;
                this.notifyIcon_0.Visible = false;
            }
        }

        private void openbutton_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog dialog = new OpenFileDialog {
                    InitialDirectory = Directory.GetCurrentDirectory(),
                    Filter = "脚本文件(*.mic)|*.mic|所有文件|*.*",
                    RestoreDirectory = true,
                    FilterIndex = 1
                };
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    string fileName = dialog.FileName;
                    this._list0.Clear();
                    this._int0 = Environment.TickCount;
                    XmlDocument document = new XmlDocument();
                    document.Load(fileName);
                    XmlNode node = document.SelectSingleNode("MacroEvents");
                    this.spannumericUpDown.Value = decimal.Parse(node.Attributes["TimeSpan"].Value);
                    this.spannumericUpDown.Value = decimal.Parse(node.Attributes["Loop"].Value);
                    foreach (XmlNode node2 in document.SelectSingleNode("MacroEvents").ChildNodes)
                    {
                        int num;
                        int num2;
                        int num3;
                        int num4;
                        string str3;
                        MouseButtons buttons;
                        MouseEventArgs args;
                        MacroEvent event2;
                        string str4;
                        Keys keys;
                        KeyEventArgs args2;
                        switch (node2.Attributes["MET"].Value)
                        {
                            case "MM":
                                num = int.Parse(node2.Attributes["X"].Value);
                                num2 = int.Parse(node2.Attributes["Y"].Value);
                                num4 = int.Parse(node2.Attributes["T"].Value);
                                args = new MouseEventArgs(MouseButtons.None, 0, num, num2, 0);
                                event2 = new MacroEvent(MacroEventType.MouseMove, args, num4);
                                this._list0.Add(event2);
                                break;

                            case "MD":
                                num = int.Parse(node2.Attributes["X"].Value);
                                num2 = int.Parse(node2.Attributes["Y"].Value);
                                num3 = int.Parse(node2.Attributes["C"].Value);
                                num4 = int.Parse(node2.Attributes["T"].Value);
                                str3 = node2.Attributes["B"].Value;
                                buttons = (MouseButtons) Enum.Parse(typeof(MouseButtons), str3, true);
                                args = new MouseEventArgs(buttons, num3, num, num2, 0);
                                event2 = new MacroEvent(MacroEventType.MouseDown, args, num4);
                                this._list0.Add(event2);
                                break;

                            case "MU":
                                num = int.Parse(node2.Attributes["X"].Value);
                                num2 = int.Parse(node2.Attributes["Y"].Value);
                                num3 = int.Parse(node2.Attributes["C"].Value);
                                num4 = int.Parse(node2.Attributes["T"].Value);
                                str3 = node2.Attributes["B"].Value;
                                buttons = (MouseButtons) Enum.Parse(typeof(MouseButtons), str3, true);
                                args = new MouseEventArgs(buttons, num3, num, num2, 0);
                                event2 = new MacroEvent(MacroEventType.MouseUp, args, num4);
                                this._list0.Add(event2);
                                break;

                            case "MW":
                            {
                                num = int.Parse(node2.Attributes["X"].Value);
                                num2 = int.Parse(node2.Attributes["Y"].Value);
                                int delta = int.Parse(node2.Attributes["D"].Value);
                                num4 = int.Parse(node2.Attributes["T"].Value);
                                str3 = node2.Attributes["B"].Value;
                                buttons = (MouseButtons) Enum.Parse(typeof(MouseButtons), str3, true);
                                args = new MouseEventArgs(buttons, 0, num, num2, delta);
                                event2 = new MacroEvent(MacroEventType.MouseWheel, args, num4);
                                this._list0.Add(event2);
                                break;
                            }
                            case "KD":
                                num4 = int.Parse(node2.Attributes["T"].Value);
                                str4 = node2.Attributes["K"].Value;
                                keys = (Keys) Enum.Parse(typeof(Keys), str4, true);
                                args2 = new KeyEventArgs(keys);
                                event2 = new MacroEvent(MacroEventType.KeyDown, args2, num4);
                                this._list0.Add(event2);
                                break;

                            case "KU":
                                num4 = int.Parse(node2.Attributes["T"].Value);
                                str4 = node2.Attributes["K"].Value;
                                keys = (Keys) Enum.Parse(typeof(Keys), str4, true);
                                args2 = new KeyEventArgs(keys);
                                event2 = new MacroEvent(MacroEventType.KeyUp, args2, num4);
                                this._list0.Add(event2);
                                break;
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }
        }

        private void playBackMacroButton_Click(object sender, EventArgs e)
        {
            this._isPlayingScript = true;
            if (!workerCmd.IsBusy)
            {
                workerCmd.RunWorkerAsync();
            }
        }

        private void recordStartButton_Click(object sender, EventArgs e)
        {
            this._list0.Clear();
            this._int0 = Environment.TickCount;
            this._keyboardHook0.Start();
            this.mouseHook_0.Start();
        }

        private void recordStopButton_Click(object sender, EventArgs e)
        {
            this._keyboardHook0.Stop();
            this.mouseHook_0.Stop();
        }

        private void savebutton_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog dialog = new SaveFileDialog {
                    InitialDirectory = Directory.GetCurrentDirectory(),
                    Filter = "脚本文件(*.mic)|*.mic|所有文件|*.*",
                    RestoreDirectory = true,
                    FilterIndex = 1
                };
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    string fileName = dialog.FileName;
                    XmlDocument document = new XmlDocument();
                    XmlElement newChild = document.CreateElement("MacroEvents");
                    newChild.SetAttribute("TimeSpan", this.spannumericUpDown.Value.ToString());
                    newChild.SetAttribute("Loop", this.loopnumericUpDown.Value.ToString());
                    document.AppendChild(newChild);
                    int num2 = 0;
                    foreach (MacroEvent event2 in this._list0)
                    {
                        KeyEventArgs args;
                        MouseEventArgs eventArgs;
                        num2++;
                        XmlElement element2 = document.CreateElement("ME" + num2.ToString());
                        switch (event2.MacroEventType)
                        {
                            case MacroEventType.MouseMove:
                                element2.SetAttribute("MET", "MM");
                                eventArgs = (MouseEventArgs) event2.EventArgs;
                                element2.SetAttribute("X", eventArgs.X.ToString());
                                element2.SetAttribute("Y", eventArgs.Y.ToString());
                                element2.SetAttribute("T", event2.TimeSinceLastEvent.ToString());
                                newChild.AppendChild(element2);
                                break;

                            case MacroEventType.MouseDown:
                                element2.SetAttribute("MET", "MD");
                                eventArgs = (MouseEventArgs) event2.EventArgs;
                                element2.SetAttribute("X", eventArgs.X.ToString());
                                element2.SetAttribute("Y", eventArgs.Y.ToString());
                                element2.SetAttribute("C", eventArgs.Clicks.ToString());
                                element2.SetAttribute("B", eventArgs.Button.ToString());
                                element2.SetAttribute("T", event2.TimeSinceLastEvent.ToString());
                                newChild.AppendChild(element2);
                                break;

                            case MacroEventType.MouseUp:
                                element2.SetAttribute("MET", "MU");
                                eventArgs = (MouseEventArgs) event2.EventArgs;
                                element2.SetAttribute("C", eventArgs.Clicks.ToString());
                                element2.SetAttribute("X", eventArgs.X.ToString());
                                element2.SetAttribute("Y", eventArgs.Y.ToString());
                                element2.SetAttribute("B", eventArgs.Button.ToString());
                                element2.SetAttribute("T", event2.TimeSinceLastEvent.ToString());
                                newChild.AppendChild(element2);
                                break;

                            case MacroEventType.MouseWheel:
                                element2.SetAttribute("MET", "MW");
                                eventArgs = (MouseEventArgs) event2.EventArgs;
                                element2.SetAttribute("X", eventArgs.X.ToString());
                                element2.SetAttribute("Y", eventArgs.Y.ToString());
                                element2.SetAttribute("B", eventArgs.Button.ToString());
                                element2.SetAttribute("D", eventArgs.Delta.ToString());
                                element2.SetAttribute("T", event2.TimeSinceLastEvent.ToString());
                                newChild.AppendChild(element2);
                                break;

                            case MacroEventType.KeyDown:
                                element2.SetAttribute("MET", "KD");
                                args = (KeyEventArgs) event2.EventArgs;
                                element2.SetAttribute("K", args.KeyData.ToString());
                                element2.SetAttribute("T", event2.TimeSinceLastEvent.ToString());
                                newChild.AppendChild(element2);
                                break;

                            case MacroEventType.KeyUp:
                                element2.SetAttribute("MET", "KU");
                                args = (KeyEventArgs) event2.EventArgs;
                                element2.SetAttribute("K", args.KeyData.ToString());
                                element2.SetAttribute("T", event2.TimeSinceLastEvent.ToString());
                                newChild.AppendChild(element2);
                                break;
                        }
                    }
                    document.Save(fileName);
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message);
            }
        }

        private void StopBackMacroButton_Click(object sender, EventArgs e)
        {
            this._isPlayingScript = false;
        }

        private void textBoxPlay_MouseHover(object sender, EventArgs e)
        {
            this._int1 = 3;
        }

        private void textBoxPlay_MouseLeave(object sender, EventArgs e)
        {
            this._int1 = 0;
        }

        private void textBoxStart_MouseHover(object sender, EventArgs e)
        {
            this._int1 = 1;
        }

        private void textBoxStart_MouseLeave(object sender, EventArgs e)
        {
            this._int1 = 0;
        }

        private void textBoxStop_MouseHover(object sender, EventArgs e)
        {
            this._int1 = 2;
        }

        private void textBoxStop_MouseLeave(object sender, EventArgs e)
        {
            this._int1 = 0;
        }

        private void textBoxStopPlay_MouseHover(object sender, EventArgs e)
        {
            this._int1 = 4;
        }

        private void textBoxStopPlay_MouseLeave(object sender, EventArgs e)
        {
            this._int1 = 0;
        }

        private void xyLyvkmwZ(object sender, EventArgs e)
        {
            this._int1 = 0;
            MessageBox.Show("快捷键设置已经保存！");
        }

        private void 打开主窗体ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            base.Show();
            base.ShowInTaskbar = true;
            this.notifyIcon_0.Visible = false;
        }

        private void 访问官网ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string str = Registry.ClassesRoot.OpenSubKey(@"http\shell\open\command\").GetValue("").ToString();
            Process.Start(str.Substring(1, str.Length - 10), "http://www.cnblogs.com/Chary/");
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this._isPlayingScript = false;
            this._keyboardHook1.Stop();
            this._keyboardHook0.Stop();
            this.mouseHook_0.Stop();
            if (workerCmd.IsBusy)
            {
                workerCmd.CancelAsync();
            }
            this.Dispose(true);
            Application.ExitThread();
        }
    }
}

